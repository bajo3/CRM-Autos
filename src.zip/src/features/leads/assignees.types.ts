export type Assignee = {
  user_id: string;
  full_name: string | null;
  role: string | null;
};
